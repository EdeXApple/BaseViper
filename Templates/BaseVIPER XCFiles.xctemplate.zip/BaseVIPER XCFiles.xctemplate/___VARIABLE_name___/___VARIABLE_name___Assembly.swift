/*
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/

import Foundation
import VIPERPLUS
import UIKit

// MARK: - dto
struct ___VARIABLE_name___AssemblyDTO {
}
// MARK: - module builder
final class ___VARIABLE_name___Assembly: BaseAssembly {

    static func navigationController(dto: ___VARIABLE_name___AssemblyDTO? = nil) -> UINavigationController {
         UINavigationController(rootViewController: view(dto: dto))
    }

    static func view(dto: ___VARIABLE_name___AssemblyDTO? = nil) -> ___VARIABLE_name___ViewController {
        let view = ___VARIABLE_name___ViewController(nibName:"___VARIABLE_name___ViewController", bundle: nil)
        let viper = BaseAssembly.assembly(baseView: view,
                                          presenter: ___VARIABLE_name___Presenter.self,
                                          router: ___VARIABLE_name___Router.self,
                                          interactor: ___VARIABLE_name___Interactor.self)
        viper.interactor.assemblyDTO = dto
        viper.interactor.provider = DataAssembly.provider(providerType: ___VARIABLE_name___Provider.self,
                                                          protocolType: ___VARIABLE_name___ProviderProtocol.self,
                                                          interactor: viper.interactor)
        return view
    }
}
